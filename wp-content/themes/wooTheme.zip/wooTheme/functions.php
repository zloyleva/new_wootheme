<?php

class WooTheme
{

    function __construct()
    {
        add_action('after_setup_theme', array($this, 'start_setup'));
        add_action('wp_enqueue_scripts', array($this, 'load_woo_theme_scripts'));
        add_filter('woocommerce_currency_symbol', array($this, 'add_ua_currency_symbol'), 10, 2);
        add_filter( 'woocommerce_checkout_fields' , array($this, 'custom_override_checkout_fields' ));

        add_action('wp_ajax_get_data_server', array($this, 'get_data_server_callback'));
        add_action('wp_ajax_nopriv_get_data_server', array($this, 'get_data_server_callback'));
    }

    function start_setup() {
        add_theme_support( 'post-thumbnails' );
        register_nav_menus( array(
            'primary' => __( 'Primary Menu' ),
            'footer'  => __( 'Footer Links Menu' ),
            'top_phone' => __('Top phone menu'),
            'top_account' => __('Top account menu'),
        ) );
        add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption' ) );
        add_theme_support( 'post-formats', array( 'aside', 'image', 'video', 'quote', 'link', 'gallery', 'status', 'audio', 'chat' ) );
        add_theme_support( 'custom-logo', array(
            'height'      => 200,
            'width'       => 200,
            'flex-height' => true,
        ) );
    }

    function load_woo_theme_scripts() {
        // Load our main stylesheet.
        wp_enqueue_style( 'my-css', get_stylesheet_uri() );
        wp_enqueue_style( 'wp-woo-styles', get_template_directory_uri() . '/css/style.css' );
        wp_enqueue_style( 'fa-font-styles', get_template_directory_uri() . '/css/font-awesome.min.css' );
        wp_enqueue_script( 'jquery', true );
        wp_localize_script('fa-font-styles', 'get_data',
            array(
                'url' => admin_url('admin-ajax.php')
            )
        );
    }

    function add_ua_currency_symbol( $currency_symbol, $currency ) {
        switch( $currency ) {
            case 'UAH': $currency_symbol = ' грн'; break;
        }
        return $currency_symbol;
    }

	/**
	 * Unset
	 * @param $fields
	 *
	 * @return mixed
	 */
    function custom_override_checkout_fields( $fields ) {
        unset($fields['billing']['billing_last_name']);
        unset($fields['billing']['billing_company']);
        unset($fields['billing']['billing_postcode']);
        unset($fields['billing']['billing_state']);

        unset($fields['shipping']['shipping_last_name']);
        unset($fields['shipping']['shipping_company']);
        unset($fields['shipping']['shipping_postcode']);
        unset($fields['shipping']['shipping_state']);
        return $fields;
    }
}
new WooTheme();